<footer class="bg-dark text-white">
    <div class="container">
 
         <div class="text-center mt-4 pt-2 pb-2">
      <p class="medium mb-0">
        © Skorial - 2025 - Administración Ecommerce. Todos los derechos reservados.
      </p>
    </div>
  </div>

    </footer>
   
    <script src=" <?php echo base_url('assets/js/bootstrap.bundle.js');?>" crossorigin="anonymous"></script>
  </body>
</html>