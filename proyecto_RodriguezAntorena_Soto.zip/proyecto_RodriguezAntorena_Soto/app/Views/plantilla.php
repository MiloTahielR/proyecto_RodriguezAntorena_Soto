<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <!--modifiqué href="assets/css/bootstrap.min.css" y agregué rel="stylesheet"-->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/miestilo.css') ; ?>">
   <!--crossorigin="anonymous"-->
    <title>Bootstrap demo</title>

  </head>
  
  <body>
    <div>  
  <?php echo "Bienvenido" ; ?>
      <h1>Hello, world!</h1> 
    </div>
   
    <div> 
      <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa sint numquam earum cum tempora quam consectetur odit hic inventore rem placeat delectus, nulla libero recusandae, molestiae blanditiis ducimus illo! Debitis. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quam omnis aspernatur assumenda voluptates at a autem, possimus nulla tempore vero sint ratione quisquam consequatur laboriosam veniam distinctio? Modi, tenetur fugiat. Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, dolorem optio id facilis dolorum, commodi quam error tenetur similique nihil, sapiente dignissimos sequi veniam! Aut vel molestiae nihil. Impedit, fugiat.</p>
    </div>
    <footer>
      <p>piesito d pag </p>
    </footer>
   
    <script src=" <?php echo base_url('assets\js\bootstrap.bundle.js');?>" crossorigin="anonymous"></script>
  </body>
</html>