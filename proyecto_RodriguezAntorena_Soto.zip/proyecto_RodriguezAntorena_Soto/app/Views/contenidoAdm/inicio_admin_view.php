<div class="container text-center mt-5 pb-5">
  <h3 class="display-4 fw-bold mb-4 Skorial_Abel">ADMINISTRACIÓN SKORIAL</h3>

  <div class="d-flex justify-content-center">
    <img src="<?= base_url('assets/img/DSC08269 (1).jpg') ?>" 
         alt="Logo admin" 
         class="img-fluid animate__animated animate__fadeIn rounded-circle shadow" 
         style="width: 250px; height: 250px; object-fit: cover;">
  </div>
</div>